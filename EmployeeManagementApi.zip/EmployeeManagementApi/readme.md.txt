Steps to build the application

1. install the maven software build the applicatioon and setup the path
2. open the application in Springtoolsuite
3. data base using json file
4. build the application using maven
5. you find Url's in employee controllers
