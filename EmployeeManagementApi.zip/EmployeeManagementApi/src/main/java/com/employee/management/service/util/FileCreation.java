package com.employee.management.service.util;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Logger;

@Component
@PropertySource(value = "classpath:application.properties", ignoreResourceNotFound = true)
public class FileCreation {

    private Environment environment;

    private String fileDir;

    private String fileName;

    private static final Logger LOGGER = Logger.getLogger(FileCreation.class.getName());

    @Autowired
    public FileCreation(Environment environment) {
        this.environment = environment;
        this.fileDir = environment.getProperty("app.fileDir");
        this.fileName = environment.getProperty("app.filename");
    }

    private void createDirectoryAndFile(final String target) {

        try {
            final Path dir = Paths.get(target + "/");
            Path file = Paths.get(target + "/" + fileName);
            if (Files.notExists(dir)) {
                LOGGER.info("Target file \"" + dir + "\" will be created.");
                Files.createDirectories(dir);
            } else {
                LOGGER.warning("Directory is exist! ");
            }
            if (Files.notExists(file)) {
                LOGGER.info("Target file \"" + file + "\" will be created.");
                Files.createFile(file);
                Files.write(file, "[]".getBytes());
            } else {
                LOGGER.warning("File is exist! ");
            }
        } catch (IOException e) {
            LOGGER.warning("Directory or file is not exist! " + e.getMessage());
        }
    }

    @Bean
    public void doStuff(){

        createDirectoryAndFile(this.fileDir);
    }

}
