package com.employee.management;

import com.employee.management.service.util.FileCreation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import java.io.IOException;
import java.util.logging.Logger;

@SpringBootApplication
public class EmployeeManagementApiApplication {

    private static FileCreation fileCreation;
    private static final Logger LOGGER = Logger.getLogger(EmployeeManagementApiApplication.class.getName());

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementApiApplication.class, args);

//		try {
        fileCreation.doStuff();
        /*} catch (IOException e) {
			LOGGER.warning("Directory or file is not exist! " + e.getMessage());
		}
*/
    }
}

