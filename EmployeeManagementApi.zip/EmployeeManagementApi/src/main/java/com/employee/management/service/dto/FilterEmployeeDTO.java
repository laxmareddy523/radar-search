package com.employee.management.service.dto;


import com.employee.management.domain.constant.Operator;
import com.employee.management.domain.constant.Sort;

public class FilterEmployeeDTO {

    private Operator operator;
    private int value;
    private Sort sort;

    public Operator getOperator() {
        return operator;
    }

    public void setOperator(Operator operator) {
        this.operator = operator;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Sort getSort() {
        return sort;
    }

    public void setSort(Sort sort) {
        this.sort = sort;
    }
}
