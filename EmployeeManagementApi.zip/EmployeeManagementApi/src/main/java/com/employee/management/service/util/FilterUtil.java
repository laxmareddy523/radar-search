package com.employee.management.service.util;


import com.employee.management.domain.Employee;
import com.employee.management.service.dto.FilterEmployeeDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class FilterUtil {

    public List<Employee> filter(FilterEmployeeDTO filterEmployeeDTO, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();

        switch (filterEmployeeDTO.getOperator()) {
            case lt:
                result = lessThan(filterEmployeeDTO.getValue(), employeeList);
                break;
            case lte:
                result = lessThanEqual(filterEmployeeDTO.getValue(), employeeList);
                break;
            case gt:
                result = greaterThan(filterEmployeeDTO.getValue(), employeeList);
                break;
            case gte:
                result = greaterThanEqual(filterEmployeeDTO.getValue(), employeeList);
                break;
            case eq:
                result = equal(filterEmployeeDTO.getValue(), employeeList);
                break;
            case ne:
                result = notEqual(filterEmployeeDTO.getValue(), employeeList);
                break;
        }
        return result;
    }

    private List<Employee> notEqual(int age, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();
        result = employeeList.stream().filter(p -> p.getAge() != age).collect(Collectors
                .toList());
        return result;
    }

    private List<Employee> equal(int age, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();
        result = employeeList.stream().filter(p -> p.getAge() == age).collect(Collectors
                .toList());
        return result;
    }

    private List<Employee> greaterThanEqual(int age, List<Employee> employeeList) {

        List<Employee> result = new ArrayList<>();
        result = employeeList.stream().filter(p -> p.getAge() >= age).collect(Collectors
                .toList());
        return result;
    }

    private List<Employee> greaterThan(int age, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();
        result = employeeList.stream().filter(p -> p.getAge() > age).collect(Collectors
                .toList());
        return result;
    }

    private List<Employee> lessThanEqual(int age, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();
        result = employeeList.stream().filter(p -> p.getAge() <= age).collect(Collectors
                .toList());
        return result;
    }

    private List<Employee> lessThan(int age, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();
        result = employeeList.stream().filter(p -> p.getAge() < age).collect(Collectors
                .toList());
        return result;
    }

}
