package com.employee.management.service;


import com.employee.management.domain.Employee;
import com.employee.management.service.dto.FilterEmployeeDTO;

import java.util.List;

public interface EmployeeService {

    List<Employee> filterByEmployee(FilterEmployeeDTO filterEmployeeDTO);

    List<String> findAll();

    Employee findById(int id);

    Employee create(Employee employee);

    Employee update(Employee employee);

    int delete(int id);
}
