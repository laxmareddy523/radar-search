package com.employee.management.domain.constant;

public enum Sort {
    asc,desc
}
