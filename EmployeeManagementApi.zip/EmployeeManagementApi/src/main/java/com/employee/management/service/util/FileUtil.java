package com.employee.management.service.util;

import com.employee.management.domain.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.List;
import java.util.logging.Logger;

@Component
public class FileUtil {

    private static final Logger LOGGER = Logger.getLogger(FileUtil.class.getName());

    private final Environment environment;

    private String fileDir;

    private String fileName;

    private Path filePath;

    @Autowired
    public FileUtil(Environment environment) {
        this.environment = environment;
        this.fileDir = environment.getProperty("app.fileDir");
        this.fileName = environment.getProperty("app.filename");
        this.filePath = Paths.get(fileDir + "/" + fileName);
    }
    public void writeToFile(Collection<Employee> employees){
        try {
            Files.write(filePath, (employees.toString()).getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<String> readFromFile(){
        List<String> outputArray = null;
        try {
            return Files.readAllLines(filePath);
        } catch (IOException e) {
            LOGGER.warning("Information is not saved! :: " + e.getMessage() + " :: ");
        }
        return null;
    }
}
