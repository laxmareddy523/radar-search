package com.employee.management.domain.constant;

public enum Operator {
   lt,lte,gt,gte,eq,ne
}
