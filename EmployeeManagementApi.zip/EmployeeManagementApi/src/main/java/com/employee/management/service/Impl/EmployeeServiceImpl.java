package com.employee.management.service.Impl;


import com.employee.management.domain.Employee;
import com.employee.management.service.dto.FilterEmployeeDTO;
import com.employee.management.service.EmployeeService;
import com.employee.management.service.util.FileUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

    private static final Logger LOGGER = Logger.getLogger(EmployeeServiceImpl.class.getName());

    private final FileUtil fileUtil;

    @Autowired
    public EmployeeServiceImpl(FileUtil fileUtil) {
        this.fileUtil = fileUtil;
    }

    @Override
    public List<Employee> filterByEmployee(FilterEmployeeDTO filterEmployeeDTO) {
        List<String> allEmployee = fileUtil.readFromFile();
        ObjectMapper objectMapper = new ObjectMapper();
        List<Employee> employees = new ArrayList<>();
        try {
            employees = objectMapper.readValue(allEmployee.get(0), new TypeReference<List<Employee>>() {
            });
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        List<Employee> result = employees.stream()
                .filter(p -> p.getAge() > filterEmployeeDTO.getValue())
                .collect(Collectors.toList());
        return result;
    }

    @Override
    public List<String> findAll() {
        return fileUtil.readFromFile();
    }


    @Override
    public Employee findById(int id) {
        List<String> allEmployee = fileUtil.readFromFile();
        if (allEmployee.get(0).equals("[]")) {
            LOGGER.info("Employee with id " + id + " does not exist");
        } else {
            ObjectMapper objectMapper = new ObjectMapper();
            List<Employee> result = new ArrayList<>();
            try {
                result = objectMapper.readValue(allEmployee.get(0), new TypeReference<List<Employee>>() {
                });
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            Employee ee = new Employee();
            ee.setId(id);
            int index = result.indexOf(ee);
            if (index == -1) {
                LOGGER.info("Employee with id " + id + " does not exist");
                return null;
            } else {
                LOGGER.info("Employee with id " + id + " was successfully returned");
                return result.get(index);
            }
        }
        return null;
    }

    @Override
    public Employee create(Employee employee) {

        List<String> allEmployee = fileUtil.readFromFile();
        if (allEmployee.get(0).equals("[]")) {
            List<Employee> employees = new ArrayList<>();
            employees.add(employee);
            fileUtil.writeToFile(employees);
            LOGGER.info("First Employee  was successfully written to a file");
        } else {
            ObjectMapper objectMapper = new ObjectMapper();
            Set<Employee> result = new LinkedHashSet<>();
            try {
                result = objectMapper.readValue(allEmployee.get(0), new TypeReference<Set<Employee>>() {
                });
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            if (!result.add(employee)) {
                LOGGER.info("Employee with id " + employee.getId() + " is exist");
            } else {
                fileUtil.writeToFile(result);
                LOGGER.info("New Employee with id " + "id" + " was successfully written to a file");
            }
        }
        return employee;
    }

    @Override
    public Employee update(Employee employee) {
        List<String> allEmployee = fileUtil.readFromFile();
        if (allEmployee.get(0).equals("[]")) {
            LOGGER.info("Employee with id " + employee.getId() + " does not exist");
        } else {
            ObjectMapper objectMapper = new ObjectMapper();
            Set<Employee> result = new LinkedHashSet<>();
            try {
                result = objectMapper.readValue(allEmployee.get(0), new TypeReference<Set<Employee>>() {
                });
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            if (!result.remove(employee)) {
                LOGGER.info("Employee with id " + employee.getId() + " does not exist");
            } else {
                result.add(employee);
                fileUtil.writeToFile(result);
                LOGGER.info("New Employee with id " + "id" + " was successfully written to a file");
            }
        }
        return employee;
    }


    @Override
    public int delete(int id) {
        List<String> allEmployee = fileUtil.readFromFile();

        if (allEmployee.get(0).equals("[]")) {
            LOGGER.info("Employee with id " + id + " does not exist");
        } else {
            ObjectMapper objectMapper = new ObjectMapper();
            Set<Employee> result = new LinkedHashSet<>();
            try {
                result = objectMapper.readValue(allEmployee.get(0), new TypeReference<Set<Employee>>() {
                });
            } catch (IOException e1) {
                e1.printStackTrace();
            }
            Employee ee = new Employee();
            ee.setId(id);
            if (!result.remove(ee)) {
                LOGGER.info("Employee with id " + id + " does not exist");
                return -1;
            } else {
                fileUtil.writeToFile(result);
                LOGGER.info("Employee with id " + id + " was successfully deleted from file");
                return 1;
            }
        }
        return -1;
    }
}
