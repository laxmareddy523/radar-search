package com.employee.management.service.util;


import com.employee.management.domain.Employee;
import com.employee.management.service.dto.FilterEmployeeDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class SortUtil {

    public List<Employee> sort(FilterEmployeeDTO filterEmployeeDTO, List<Employee> employeeList) {
        List<Employee> result = new ArrayList<>();
        switch (filterEmployeeDTO.getSort()) {
            case asc:
                result = ascSort(result);
                break;
            case desc:
                result = descSort(result);
                break;
        }
        return result;
    }

    private List<Employee> descSort(List<Employee> employeeList) {
        return employeeList.stream().sorted(Comparator.comparing(Employee::getAge).reversed()).collect(Collectors.toList()) ;
    }

    private List<Employee> ascSort(List<Employee> employeeList) {
        return employeeList.stream().sorted(Comparator.comparing(Employee::getAge)).collect(Collectors.toList()) ;
    }
}