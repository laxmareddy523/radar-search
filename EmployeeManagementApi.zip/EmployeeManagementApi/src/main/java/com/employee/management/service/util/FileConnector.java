/*
package com.employee.management.service.util;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@ComponentScan(basePackages = "com.employee.management")
@PropertySource(value = "classpath:application.properties", ignoreResourceNotFound = true)
public class FileConnector {

     @Autowired
     private Environment environment;

    @Value("${app.fileDir}")
    private String fileDir;

    @Value("${app.filename}")
    private String fileName;

    private String filePath = fileDir + "/" + fileName;

    public FileConnector(Environment environment) {
        this.environment = environment;
        this.fileDir = environment.getProperty("app.fileDir");
        this.fileName = environment.getProperty("app.filename");
    }

    public String getFileDir() {
        return fileDir;
    }

    public void setFileDir(String fileDir) {
        this.fileDir = fileDir;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
*/
