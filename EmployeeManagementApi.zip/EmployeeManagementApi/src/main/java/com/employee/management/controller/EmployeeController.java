package com.employee.management.controller;


import com.employee.management.domain.Employee;
import com.employee.management.service.dto.FilterEmployeeDTO;
import com.employee.management.service.EmployeeService;
import com.employee.management.service.util.FilterUtil;
import com.employee.management.service.util.SortUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@RestController
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    @Autowired
    private FilterUtil filterEmployee;

    @Autowired
    private SortUtil sortEmployee;

    private static final Logger LOGGER = Logger.getLogger(EmployeeController.class.getName());

    @GetMapping(value = "/getAllEmployees")
    @ResponseBody
    public ResponseEntity getAllEmployees() {
        HttpHeaders headers = new HttpHeaders();
//        List<Employee> result = employeeService.findAll();
        List<String> result = employeeService.findAll();
        if (!ObjectUtils.isEmpty(result)) {
            return new ResponseEntity<>(result, headers, HttpStatus.OK);
        } else {
            LOGGER.warning(" The List Is empty !");
            return new ResponseEntity<>(" Please insert a new Employee !", headers, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(value = "/getEmployeeInfo/{id}")
    @ResponseBody
    public ResponseEntity getEmployeeInfo(@PathVariable int id) {
        HttpHeaders headers = new HttpHeaders();
        Employee result = null;
        if (id != 0L) {
            result = new Employee();
            result = employeeService.findById(id);
            if (!ObjectUtils.isEmpty(result)) {
                return new ResponseEntity<>(result, headers, HttpStatus.OK);
            } else {
                LOGGER.warning("the employee id is not existed !");
                return new ResponseEntity<>("the employee id is not existed !", headers, HttpStatus.BAD_REQUEST);
            }
        } else {
            LOGGER.warning("inserted id is not valid !");
            return new ResponseEntity<>("inserted id is not valid !", headers, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping(value = "/saveEmployeeInfo", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity saveEmployeeInfo(@RequestBody Employee employee) {

        HttpHeaders headers = new HttpHeaders();
        Employee result = null;
        if (!ObjectUtils.isEmpty(employee)) {
            result = new Employee();
            result = employeeService.create(employee);
            if (!ObjectUtils.isEmpty(result)) {
                return new ResponseEntity<>(result, headers, HttpStatus.CREATED);
            } else {
                LOGGER.warning("Information is not saved! ");
                return new ResponseEntity<>("Employee Information Did not Save! ", headers, HttpStatus.BAD_REQUEST);
            }
        } else {
            LOGGER.warning("Please insert  Employee !");
            return new ResponseEntity<>("Please insert Employee Information!", headers, HttpStatus.BAD_REQUEST);
        }
    }


    @PutMapping(value = "/updateEmployeeInfo/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity updateEmployeeInfo(@RequestBody Employee employee) {
        HttpHeaders headers = new HttpHeaders();

        Employee result = null;
        if (!ObjectUtils.isEmpty(employee)) {
            result = new Employee();
            result = employeeService.update(employee);

            if (!ObjectUtils.isEmpty(result)) {
                return new ResponseEntity<>(result, headers, HttpStatus.CREATED);
            } else {
                LOGGER.warning("Information is not updated! ");
                return new ResponseEntity<>("Employee Information Did not update! ", headers, HttpStatus.BAD_REQUEST);
            }
        } else {
            LOGGER.warning("Please insert  Employee ID!");
            return new ResponseEntity<>("Please insert Employee ID!", headers, HttpStatus.BAD_REQUEST);
        }
    }


    @DeleteMapping(value = "/deleteEmployeeInfo/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity deleteEmployeeInfo(@PathVariable int id) {
        HttpHeaders headers = new HttpHeaders();

        if (id != 0L) {
            int result = employeeService.delete(id);

            if (result == 1) {
                return new ResponseEntity<>(result, headers, HttpStatus.CREATED);
            } else {
                LOGGER.warning("Information is not deleted! ");
                return new ResponseEntity<>("Employee Information Did not delete! ", headers, HttpStatus.BAD_REQUEST);
            }
        } else {
            LOGGER.warning("Please insert  Employee ID!");
            return new ResponseEntity<>("Please insert Employee ID!", headers, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/filterByAge")
    public ResponseEntity<List<Employee>> filterByAge(@RequestBody FilterEmployeeDTO filterEmploee) {
        HttpHeaders headers = new HttpHeaders();

        List<Employee> employees = getAllEmployee();
        List<Employee> result = null;

        if (filterEmploee.getOperator() != null && filterEmploee.getValue() != 0
                && filterEmploee.getSort() != null) {
            result = new ArrayList<>();
            result = filterEmployee.filter(filterEmploee, employees);
            result = sortEmployee.sort(filterEmploee, employees);
            return new ResponseEntity<>(result, headers, HttpStatus.OK);

        } else if (filterEmploee.getOperator() != null && filterEmploee.getValue() != 0
                && filterEmploee.getSort() == null) {
            result = new ArrayList<>();
            result = filterEmployee.filter(filterEmploee, employees);
            return new ResponseEntity<>(result, headers, HttpStatus.OK);

        } else if (filterEmploee.getOperator() == null && filterEmploee.getValue() == 0
                && filterEmploee.getSort() != null) {
            result = sortEmployee.sort(filterEmploee, employees);
            return new ResponseEntity<>(result, headers, HttpStatus.OK);

        } else {
            LOGGER.warning("input json is not recognizable !");
            return new ResponseEntity<>(headers, HttpStatus.BAD_REQUEST);
        }

    }


    public List<Employee> getAllEmployee() {
        Employee employee1 = new Employee();
        employee1.setId(1);
        employee1.setAge(24);
        employee1.setFullName("Employee A");
        employee1.setSalary(4500);

        Employee employee2 = new Employee();
        employee2.setId(2);
        employee2.setAge(32);
        employee2.setFullName("Employee B");
        employee2.setSalary(6500);

        List<Employee> employees = new ArrayList<>();
        employees.add(employee1);
        employees.add(employee2);
        return employees;
    }


}
