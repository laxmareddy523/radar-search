package com.employee.management;

import com.employee.management.controller.EmployeeController;
import com.employee.management.domain.Employee;
import com.employee.management.domain.constant.Operator;
import com.employee.management.domain.constant.Sort;
import com.employee.management.service.EmployeeService;
import com.employee.management.service.dto.FilterEmployeeDTO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(EmployeeController.class)
public class EmployeeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private EmployeeService employeeService;

    @Test
    public void findAll_TodosFound_ShouldReturnFoundTodoEntries() throws Exception {
        Employee employee1 = new Employee();
        employee1.setId(100000);
        employee1.setAge(24);
        employee1.setFullName("Employee A");
        employee1.setSalary(4500);

        Employee employee2 = new Employee();
        employee1.setId(200000);
        employee1.setAge(32);
        employee1.setFullName("Employee B");
        employee1.setSalary(6500);

        employeeService.create(employee1);
        employeeService.create(employee2);

        List<Employee> employees = new ArrayList<>();
        employees.add(employee1);
        employees.add(employee2);

        FilterEmployeeDTO filterEmployeeDTO = new FilterEmployeeDTO();
        filterEmployeeDTO.setValue(34);
        filterEmployeeDTO.setOperator(Operator.lt);
        filterEmployeeDTO.setSort(Sort.asc);

        mockMvc.perform(post("/filterByAge").contentType(MediaType.APPLICATION_JSON).content(filterEmployeeDTO.toString()))
                .andExpect(status().isOk())
                .andExpect(content().contentType(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(100000)))
                .andExpect(jsonPath("$[0].age", is(24)))
                .andExpect(jsonPath("$[0].fullName", is("Employee A")))
                .andExpect(jsonPath("$[1].id", is(200000)))
                .andExpect(jsonPath("$[1].age", is(32)))
                .andExpect(jsonPath("$[1].fullName", is("Employee B")));

        employeeService.delete(employee1.getId());
        employeeService.delete(employee2.getId());
    }
}
