package com.employee.management;

import com.employee.management.domain.Employee;
import com.employee.management.domain.EmployeeList;
import com.employee.management.service.EmployeeService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeManagementApiApplicationTests {

	@Autowired
	private EmployeeService employeeService;

	@Test
	public void create() {
		Employee employee1 = new Employee();
		employee1.setId(4);
		employee1.setAge(24);
		employee1.setFullName("Employee A");
		employee1.setSalary(4500);
		employeeService.create(employee1);
	}

//	@Test
//	public void cree() {
//		String test = "[{\"id\":\"1\",\"fullName\":\"Employee A\",\"age\":\"24\",\"salary\":\"4500.0\"}, {\"id\":\"2\",\"fullName\":\"Employee A\",\"age\":\"24\",\"salary\":\"4500.0\"}]";
////		String test2 = "{\"id\":\"1\",\"fullName\":\"Employee A\",\"age\":\"24\",\"salary\":\"4500.0\"}";
//		ObjectMapper objectMapper = new ObjectMapper();
////		EmployeeList employeeList = null;
//		List<Employee> employees= new ArrayList<>();
//		Employee employee= null;
//		try {
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		employee = (Employee) employees.get(0);
//		System.err.println(employees.toString());
////		System.err.println(employee.toString());
//
//	}

	@Test
	public void cree() {
		ObjectMapper objectMapper = new ObjectMapper();
		String test = "[{\"id\":\"1\",\"fullName\":\"Employee A\",\"age\":\"24\",\"salary\":\"4500.0\"}, {\"id\":\"2\",\"fullName\":\"Employee A\",\"age\":\"24\",\"salary\":\"4500.0\"}]";
		Set<Employee> eeee = new LinkedHashSet<>();
		try {
			eeee = objectMapper.readValue(test, new TypeReference<Set<Employee>>(){});
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		String[] ss = test.split("[\\[]|},|[}\\]]");
		System.out.println();
		List<Employee> list = new ArrayList<>();
		for (int i = 1; i < ss.length; i++) {
			try {
				list.add(objectMapper.readValue(ss[i]+"}",Employee.class));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}

